# FitBuddy – AI Fitness Plan Generator

FitBuddy is a FastAPI web application that generates a structured 7-day
fitness/wellness plan and a nutrition or recovery tip. It stores users and
plans in SQLite and lets users submit feedback to create an updated plan.

## Features

- FastAPI backend
- HTML + Jinja2 frontend
- SQLite + SQLAlchemy database
- Gemini AI integration
- 7-day plan generation
- Nutrition/recovery tip generation
- Feedback-based plan updating
- Admin/coach dashboard
- Delete user feature
- REST/API documentation through FastAPI `/docs`
- Demo fallback when a Gemini API key is not configured

## Project Structure

```text
FitBuddy_AI_Fitness_Plan_Generator/
│
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   ├── database.py
│   ├── schemas.py
│   ├── gemini_generator.py
│   ├── gemini_flash_generator.py
│   └── updated_plan.py
│
├── templates/
│   ├── index.html
│   ├── result.html
│   └── all_users.html
│
├── static/
│   └── css/
│       └── style.css
│
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. Open the project in VS Code

Extract the ZIP and open the extracted `FitBuddy_AI_Fitness_Plan_Generator`
folder in VS Code.

## 2. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

PowerShell:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

## 3. Install packages

```bash
pip install -r requirements.txt
```

## 4. Configure Gemini

Copy:

```text
.env.example
```

to:

```text
.env
```

Then put your Gemini API key into:

```text
GOOGLE_API_KEY=your_real_key_here
```

Do not put the API key directly inside Python files.

## 5. Start the application

From the project root:

```bash
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

FastAPI documentation:

```text
http://127.0.0.1:8000/docs
```

Health check:

```text
http://127.0.0.1:8000/health
```

Admin dashboard:

```text
http://127.0.0.1:8000/view-all-users
```

## 6. If you do not have a Gemini API key yet

The application includes a demo fallback. The website can still run and
display a sample plan. Once `GOOGLE_API_KEY` is configured, Gemini generation
is used.

## Main routes

- `GET /` – home/input form
- `POST /generate-workout` – generate plan + nutrition tip
- `POST /submit-feedback` – update plan using feedback
- `GET /view-all-users` – admin/coach dashboard
- `POST /delete-user/{user_id}` – delete a user and associated plans
- `GET /docs` – FastAPI interactive API docs
- `GET /health` – application health check

## Database

The first application start automatically creates:

```text
fitbuddy.db
```

The database contains:

- users
- plans
- original plan
- updated plan
- feedback
- nutrition tip

## Important

FitBuddy is a general wellness application. It is not intended to diagnose
conditions or replace professional medical advice. Users should adjust
activities to their abilities and seek appropriate professional guidance for
health concerns.
