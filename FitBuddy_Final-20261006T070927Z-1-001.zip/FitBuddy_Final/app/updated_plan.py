import os

try:
    from google import genai
except ImportError:
    genai = None


def update_workout_plan(original_plan: str, feedback: str) -> str:
    api_key = os.getenv("GOOGLE_API_KEY")

    if api_key and genai is not None:
        try:
            client = genai.Client(api_key=api_key)
            model = os.getenv("GEMINI_WORKOUT_MODEL", "gemini-2.5-flash")

            prompt = f"""
Update the following FitBuddy 7-day fitness/wellness plan according to the
user's feedback.

ORIGINAL PLAN:
{original_plan}

USER FEEDBACK:
{feedback}

Return a complete revised seven-day plan, not only the changed section.
Keep it general, realistic, safety-conscious, and easy to follow.
Do not provide medical diagnosis, extreme exercise, restrictive eating,
or guaranteed results. Include recovery/rest guidance.
"""
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            if response.text:
                return response.text.strip()
        except Exception as exc:
            print(f"Gemini update failed: {exc}")

    return f"""UPDATED FITBUDDY PLAN

The plan was revised using this feedback:
"{feedback}"

ORIGINAL PLAN:
{original_plan}

Suggested adjustment:
Apply the requested change gradually while keeping recovery time in the
schedule. If an activity causes pain or unusual symptoms, stop and seek
appropriate professional guidance."""
