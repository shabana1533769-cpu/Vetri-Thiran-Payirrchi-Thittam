import os
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .database import init_db
from .routes import router

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE_DIR, ".env"))

app = FastAPI(
    title="FitBuddy – AI Fitness Plan Generator",
    description="AI-assisted 7-day fitness and wellness plan generator.",
    version="1.0.0",
)

app.mount(
    "/static",
    StaticFiles(directory=os.path.join(BASE_DIR, "static")),
    name="static"
)

init_db()
app.include_router(router)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "FitBuddy",
        "gemini_configured": bool(os.getenv("GOOGLE_API_KEY")),
    }
