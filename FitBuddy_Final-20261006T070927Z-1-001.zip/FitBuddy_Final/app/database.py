import os
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "fitbuddy.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(100), unique=True, nullable=False, index=True)
    username = Column(String(100), nullable=False)
    age = Column(Integer, nullable=False)
    weight = Column(String(30), nullable=False)
    goal = Column(String(100), nullable=False)
    intensity = Column(String(30), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Plan(Base):
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(100), nullable=False, index=True)
    original_plan = Column(Text, nullable=False)
    updated_plan = Column(Text, nullable=True)
    nutrition_tip = Column(Text, nullable=True)
    feedback = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=True)


def init_db():
    Base.metadata.create_all(bind=engine)


def save_user(user_id, username, age, weight, goal, intensity):
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.user_id == user_id).first()
        if existing:
            existing.username = username
            existing.age = age
            existing.weight = weight
            existing.goal = goal
            existing.intensity = intensity
        else:
            db.add(User(
                user_id=user_id,
                username=username,
                age=age,
                weight=weight,
                goal=goal,
                intensity=intensity
            ))
        db.commit()
    finally:
        db.close()


def save_plan(user_id, original_plan, nutrition_tip):
    db = SessionLocal()
    try:
        plan = Plan(
            user_id=user_id,
            original_plan=original_plan,
            nutrition_tip=nutrition_tip
        )
        db.add(plan)
        db.commit()
        db.refresh(plan)
        return plan.id
    finally:
        db.close()


def get_user(user_id):
    db = SessionLocal()
    try:
        return db.query(User).filter(User.user_id == user_id).first()
    finally:
        db.close()


def get_plan(user_id):
    db = SessionLocal()
    try:
        return (
            db.query(Plan)
            .filter(Plan.user_id == user_id)
            .order_by(Plan.id.desc())
            .first()
        )
    finally:
        db.close()


def get_original_plan(user_id):
    plan = get_plan(user_id)
    return plan.original_plan if plan else None


def update_plan(user_id, updated_plan, feedback):
    db = SessionLocal()
    try:
        plan = (
            db.query(Plan)
            .filter(Plan.user_id == user_id)
            .order_by(Plan.id.desc())
            .first()
        )
        if not plan:
            return False

        plan.updated_plan = updated_plan
        plan.feedback = feedback
        plan.updated_at = datetime.utcnow()
        db.commit()
        return True
    finally:
        db.close()


def get_all_users_with_plans():
    db = SessionLocal()
    try:
        users = db.query(User).order_by(User.id.desc()).all()
        result = []
        for user in users:
            plan = (
                db.query(Plan)
                .filter(Plan.user_id == user.user_id)
                .order_by(Plan.id.desc())
                .first()
            )
            result.append({"user": user, "plan": plan})
        return result
    finally:
        db.close()


def delete_user(user_id):
    db = SessionLocal()
    try:
        db.query(Plan).filter(Plan.user_id == user_id).delete()
        db.query(User).filter(User.user_id == user_id).delete()
        db.commit()
    finally:
        db.close()
