import os
from typing import Optional

try:
    from google import genai
except ImportError:
    genai = None


def _client():
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key or genai is None:
        return None
    return genai.Client(api_key=api_key)


def generate_workout_gemini(
    username: str,
    age: int,
    weight: str,
    goal: str,
    intensity: str,
) -> str:
    """
    Generates a structured 7-day wellness-oriented plan.
    If Gemini is not configured, a safe demo plan is returned so the
    application can still be demonstrated locally.
    """
    client = _client()

    prompt = f"""
Create a practical 7-day beginner-friendly fitness and wellness plan.

User:
- Name: {username}
- Age: {age}
- Weight: {weight}
- Goal: {goal}
- Preferred intensity: {intensity}

Return exactly seven labeled days. For each day include:
1. Focus
2. Warm-up (5-10 minutes)
3. Main activity with simple exercise names and suggested sets/reps or duration
4. Rest/recovery guidance
5. Cool-down

Important:
- Keep recommendations general and safety-conscious.
- Do not diagnose medical conditions.
- Do not promise weight-loss results.
- Encourage stopping if there is pain or unusual symptoms.
- Avoid extreme dieting or exercise.
- Include at least one recovery/rest day.
- Make the plan easy to read in plain text.
"""

    if client:
        model = os.getenv("GEMINI_WORKOUT_MODEL", "gemini-2.5-flash")
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            if response.text:
                return response.text.strip()
        except Exception as exc:
            print(f"Gemini workout generation failed: {exc}")

    return demo_workout_plan(goal, intensity)


def demo_workout_plan(goal: str, intensity: str) -> str:
    return f"""FITBUDDY 7-DAY WELLNESS PLAN
Goal: {goal}
Preferred intensity: {intensity}

DAY 1 — FULL BODY
Warm-up: 5–10 minutes easy walking and mobility.
Main: Bodyweight squats 2 x 10, wall/incline push-ups 2 x 8, glute bridges 2 x 10, easy walking 10 minutes.
Recovery: Gentle stretching and hydration.

DAY 2 — CARDIO & MOBILITY
Warm-up: 5 minutes easy movement.
Main: Comfortable brisk walk 20–25 minutes + gentle mobility.
Recovery: Easy stretching.

DAY 3 — UPPER BODY & CORE
Warm-up: 5–10 minutes.
Main: Wall/incline push-ups 2 x 8, bird-dog 2 x 8 each side, dead bug 2 x 8 each side.
Recovery: Rest as needed between sets.

DAY 4 — RECOVERY
Main: Easy walk or gentle stretching for 15–20 minutes.
Recovery: Prioritize comfortable movement and rest.

DAY 5 — LOWER BODY
Warm-up: 5–10 minutes.
Main: Bodyweight squats 2 x 10, reverse lunges with support 2 x 6 each side, calf raises 2 x 12.
Recovery: Gentle stretching.

DAY 6 — LIGHT CARDIO & CORE
Warm-up: 5 minutes.
Main: Comfortable walk 20 minutes + plank from knees or wall hold 2 x 15–20 seconds.
Recovery: Hydrate and relax.

DAY 7 — ACTIVE RECOVERY
Main: Easy walking, stretching, or another comfortable low-intensity activity for 15–25 minutes.
Recovery: Prepare for the next week.

Note: This is a general wellness example, not medical advice. Adjust activity to your experience and comfort."""
