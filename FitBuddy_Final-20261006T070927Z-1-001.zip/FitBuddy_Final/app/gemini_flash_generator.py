import os

try:
    from google import genai
except ImportError:
    genai = None


def generate_nutrition_tip_with_flash(goal: str) -> str:
    client = None
    api_key = os.getenv("GOOGLE_API_KEY")

    if api_key and genai is not None:
        try:
            client = genai.Client(api_key=api_key)
        except Exception:
            client = None

    prompt = f"""
Give one concise, practical nutrition or recovery tip for a person whose
fitness goal is "{goal}".

Keep it general and health-oriented. Do not prescribe a restrictive diet,
supplements, calorie targets, or medical treatment. Mention balanced meals,
hydration, and recovery where appropriate. Limit the response to 3-5 sentences.
"""

    if client:
        model = os.getenv("GEMINI_TIP_MODEL", "gemini-2.5-flash")
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            if response.text:
                return response.text.strip()
        except Exception as exc:
            print(f"Gemini nutrition generation failed: {exc}")

    return (
        f"For a goal of {goal}, focus on balanced meals that include protein, "
        "vegetables or fruit, carbohydrates, and healthy fats. Drink water regularly "
        "and give your body enough time to recover between demanding sessions. "
        "Individual nutrition needs can vary."
    )
