from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from .database import (
    save_user,
    save_plan,
    get_user,
    get_plan,
    get_original_plan,
    update_plan,
    get_all_users_with_plans,
    delete_user,
)
from .schemas import UserInput, FeedbackRequest
from .gemini_generator import generate_workout_gemini
from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .updated_plan import update_workout_plan

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )


@router.post("/generate-workout", response_class=HTMLResponse)
async def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: str = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
):
    data = UserInput(
        username=username,
        user_id=user_id,
        age=age,
        weight=weight,
        goal=goal,
        intensity=intensity,
    )

    workout_plan = generate_workout_gemini(
        data.username,
        data.age,
        data.weight,
        data.goal,
        data.intensity,
    )
    nutrition_tip = generate_nutrition_tip_with_flash(data.goal)

    save_user(
        data.user_id,
        data.username,
        data.age,
        data.weight,
        data.goal,
        data.intensity,
    )
    save_plan(data.user_id, workout_plan, nutrition_tip)

    return templates.TemplateResponse(
        "result.html",
        {
            "request": request,
            "user": data,
            "workout_plan": workout_plan,
            "nutrition_tip": nutrition_tip,
            "updated_plan": None,
            "message": None,
        },
    )


@router.post("/submit-feedback", response_class=HTMLResponse)
async def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
):
    feedback_data = FeedbackRequest(
        user_id=user_id,
        feedback=feedback,
    )

    user = get_user(feedback_data.user_id)
    plan = get_plan(feedback_data.user_id)

    if not user or not plan:
        raise HTTPException(status_code=404, detail="User or plan not found.")

    revised_plan = update_workout_plan(
        plan.original_plan,
        feedback_data.feedback
    )

    update_plan(
        feedback_data.user_id,
        revised_plan,
        feedback_data.feedback
    )

    return templates.TemplateResponse(
        "result.html",
        {
            "request": request,
            "user": user,
            "workout_plan": plan.original_plan,
            "nutrition_tip": plan.nutrition_tip,
            "updated_plan": revised_plan,
            "message": "Your plan has been updated using your feedback.",
        },
    )


@router.get("/view-all-users", response_class=HTMLResponse)
async def view_all_users(request: Request):
    records = get_all_users_with_plans()
    return templates.TemplateResponse(
        "all_users.html",
        {
            "request": request,
            "records": records,
        },
    )


@router.post("/delete-user/{user_id}")
async def remove_user(user_id: str):
    delete_user(user_id)
    return RedirectResponse(
        url="/view-all-users",
        status_code=303
    )
